/*
 * Функция поиска пароля по известному хэшу перестановкой символов пароля
 * Параметры:
 *        startPass — начальное значение пароля
 *        hash  - хэш-функция от пароля
 * Функция использует следующие заголовочные файлы:
 *     algorithm — алгоритмы стандартной библиотеки
 *     crypt.h — криптографические функции Linux
 */
void findPass(string pass, const string& hash)
{
    crypt_data *pCryptData = new crypt_data;
    size_t pos = hash.find_last_of('$');
    string hashHead = hash.substr(0,pos);
    do {
        string newHash(crypt_r(pass.data(),hashHead.data(),pCryptData));
        if (newHash == hash) {
            cout<<"Hash: "<<hash<<endl<<"Pass: "<<pass<<endl;
            break;
        }
    } while ( next_permutation( pass.begin(), pass.end() ) );
    delete pCryptData;
}

